import pandas as pd
import pickle
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score

### loading dataset
iris_data = pd.read_excel("iris .xls")

### encodes the target variable 'Classification'
label_encoder = LabelEncoder()
iris_data['Classification'] = label_encoder.fit_transform(iris_data['Classification'])

### extract feature variable (x) and target variable (y)
X = iris_data.drop('Classification', axis=1)
y = iris_data['Classification']

### splitting dataset into training and testing dataset
X_train,X_test,y_train,y_test = train_test_split(X,y,test_size=0.2,random_state=42)

### training RandomForestClassifier
rfc_model = RandomForestClassifier()
rfc_model.fit(X_train, y_train)
rfc_model.feature_names = list(X.columns)


### prediction
y_pred = rfc_model.predict(X_test)

### accuracy checking
accuracy = accuracy_score(y_test, y_pred)
print(f"Accuracy on the testing set: {accuracy}")

### saving the trained model to the 'model.pkl' file
pickle.dump(rfc_model,open('model.pkl','wb'))