from flask import Flask, render_template, request
import pickle
import numpy as np

app = Flask(__name__)
model = pickle.load(open('model.pkl', 'rb'))

@app.route('/')
def home():
    return render_template('home.html')

@app.route('/classification', methods=['POST'])
def classification():
    sepal_length = float(request.form['sepal_length'])
    sepal_width = float(request.form['sepal_width'])
    petal_length = float(request.form['petal_length'])
    petal_width = float(request.form['petal_width'])

    iris_data = np.array([[sepal_length, sepal_width, petal_length, petal_width]])
    print("Input data:", iris_data)
    
    prediction = model.predict(iris_data)[0]
    print("Prediction:", prediction) 

    return render_template('res.html', classification_text=f"The classification result of Iris Species is : {prediction}")

if __name__ == '__main__':
    app.run(port=8000, debug=True)